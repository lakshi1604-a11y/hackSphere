-- HackSphere Database Migration
-- This creates all the tables needed for the hackathon platform

-- Enable UUID extension for PostgreSQL
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE "users" (
  "id" VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  "name" TEXT NOT NULL,
  "username" TEXT NOT NULL UNIQUE,
  "password" TEXT NOT NULL,
  "skills" JSON NOT NULL DEFAULT '[]',
  "bio" TEXT,
  "avatar" TEXT,
  "role" TEXT NOT NULL DEFAULT 'participant',
  "created_at" TIMESTAMP DEFAULT NOW()
);

-- Events table
CREATE TABLE "events" (
  "id" VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  "title" TEXT NOT NULL,
  "theme" TEXT,
  "tracks" JSON NOT NULL DEFAULT '[]',
  "rules" JSON NOT NULL DEFAULT '[]',
  "prizes" JSON NOT NULL DEFAULT '[]',
  "sponsors" JSON NOT NULL DEFAULT '[]',
  "mode" TEXT NOT NULL DEFAULT 'online',
  "timeline" JSON NOT NULL DEFAULT '[]',
  "created_by" VARCHAR NOT NULL,
  "created_at" TIMESTAMP DEFAULT NOW()
);

-- Teams table
CREATE TABLE "teams" (
  "id" VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  "event_id" VARCHAR NOT NULL,
  "name" TEXT NOT NULL,
  "members" JSON NOT NULL DEFAULT '[]',
  "created_at" TIMESTAMP DEFAULT NOW()
);

-- Submissions table
CREATE TABLE "submissions" (
  "id" VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  "event_id" VARCHAR NOT NULL,
  "team_id" VARCHAR,
  "title" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "github" TEXT,
  "video" TEXT,
  "track" TEXT,
  "tags" JSON NOT NULL DEFAULT '[]',
  "scores" JSON NOT NULL DEFAULT '[]',
  "created_at" TIMESTAMP DEFAULT NOW()
);

-- Announcements table
CREATE TABLE "announcements" (
  "id" VARCHAR PRIMARY KEY DEFAULT gen_random_uuid(),
  "event_id" VARCHAR NOT NULL,
  "message" TEXT NOT NULL,
  "by" TEXT NOT NULL,
  "created_at" TIMESTAMP DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_events_created_by ON "events"("created_by");
CREATE INDEX idx_teams_event_id ON "teams"("event_id");
CREATE INDEX idx_submissions_event_id ON "submissions"("event_id");
CREATE INDEX idx_submissions_team_id ON "submissions"("team_id");
CREATE INDEX idx_announcements_event_id ON "announcements"("event_id");

-- Insert some initial data for testing
INSERT INTO "users" ("name", "username", "password", "skills", "bio", "avatar", "role") VALUES
('Lakshmi', 'lakshmi', 'hashed_password_1', '["React", "UI/UX", "Arduino"]', 'Frontend wizard + IoT tinkerer', '🪄', 'participant'),
('Amrutha', 'amrutha', 'hashed_password_2', '["Python", "ML", "NLP"]', 'ML generalist who ships fast', '🤖', 'participant'),
('Himashi', 'himashi', 'hashed_password_3', '["Node", "SQL", "DevOps"]', 'Loves scalable backends', '🛠️', 'participant'),
('Saumya', 'saumya', 'hashed_password_4', '["Figma", "3D", "Three.js"]', 'Design + 3D micro-interactions', '🎨', 'participant'),
('Admin', 'admin', 'hashed_password_admin', '["Management", "Strategy"]', 'Platform administrator', '👑', 'organizer');