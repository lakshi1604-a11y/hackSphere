# HackSphere - Metaverse Hackathon Platform

## Overview

HackSphere is a comprehensive hackathon management platform designed to facilitate metaverse-style hackathon events. The application provides role-based dashboards for organizers, participants, and judges, featuring event creation, team formation through a swipe-based matching system, project submissions with live feeds, AI-assisted judging capabilities, and real-time leaderboards. The platform emphasizes a modern, neon-themed UI with dark mode aesthetics and uses local storage for data persistence in its MVP form.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The application uses a React-based Single Page Application (SPA) built with Vite as the build tool. The frontend architecture follows a component-based structure using:

- **React 18** with TypeScript for type safety and modern React features
- **Wouter** for lightweight client-side routing instead of React Router
- **Framer Motion** for smooth animations and transitions
- **shadcn/ui** component library with Radix UI primitives for accessible UI components
- **Tailwind CSS** for utility-first styling with custom dark theme variables
- **TanStack Query** (React Query) for state management and data fetching
- **React Hook Form** with Zod validation for form handling

The main application component (`HackSphere.tsx`) contains the entire application logic in a single file, implementing a metaverse-style hackathon platform with role-based dashboards, team matching, and project management features.

### Backend Architecture
The backend is built using Express.js with TypeScript in ESM module format. Key architectural decisions include:

- **Express.js** server with middleware for JSON parsing and request logging
- **Modular route structure** with routes defined in separate files and registered through a central handler
- **Storage abstraction layer** with an interface-based design allowing for different storage implementations (currently in-memory storage with plans for database integration)
- **Error handling middleware** for centralized error processing
- **Development-specific features** including Vite integration and runtime error overlays

### Data Storage Solutions
The application uses a hybrid storage approach:

- **Local Storage** for client-side data persistence in MVP mode, storing users, events, projects, and application state
- **Drizzle ORM** configured for PostgreSQL integration for future database migration
- **Neon Database** as the planned PostgreSQL provider (configured but not yet implemented)
- **In-memory storage** on the server side with interface-based design for easy migration to persistent storage

The database schema defines a users table with ID, username, and password fields, using PostgreSQL-specific features like `gen_random_uuid()` for primary key generation.

### External Dependencies

- **@neondatabase/serverless** - Serverless PostgreSQL database driver for Neon
- **Drizzle ORM** - Type-safe database ORM with PostgreSQL dialect support
- **shadcn/ui + Radix UI** - Comprehensive UI component library with accessibility features
- **Framer Motion** - Animation library for smooth transitions and interactions
- **TanStack Query** - Server state management and caching
- **Tailwind CSS** - Utility-first CSS framework with custom theming
- **Zod** - Schema validation library integrated with forms and database operations
- **React Hook Form** - Form state management with validation
- **Wouter** - Lightweight routing library
- **date-fns** - Date manipulation and formatting utilities

The application is configured for deployment on Replit with specific plugins for development environment integration and error handling.