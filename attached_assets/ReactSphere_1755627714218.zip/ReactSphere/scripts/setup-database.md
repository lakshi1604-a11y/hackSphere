# HackSphere Database Setup Guide

## Azure Database Setup

### 1. Create Azure PostgreSQL Database

1. Go to the Azure Portal
2. Create a new PostgreSQL Flexible Server
3. Configure your database settings:
   - Choose your subscription and resource group
   - Set a server name (e.g., `hacksphere-db`)
   - Choose PostgreSQL version 14 or higher
   - Set admin username and password
   - Choose your preferred region

### 2. Configure Database Connection

1. In your Azure PostgreSQL server settings:
   - Go to "Connection security"
   - Add your current IP address to the firewall rules
   - Enable "Allow access to Azure services"

2. Get your connection string:
   - Go to "Connection strings" in your Azure database
   - Copy the "Node.js" connection string
   - It should look like:
     ```
     postgresql://username:password@hostname:5432/postgres?ssl=true
     ```

### 3. Set Environment Variable

Add your DATABASE_URL to the environment variables in Replit.

### 4. Run Database Migration

1. Connect to your Azure database using psql or Azure Data Studio
2. Run the SQL migration script located at `drizzle/0000_initial.sql`
3. This will create all the necessary tables and indexes

### 5. Test the Connection

Once your DATABASE_URL is configured, the application will automatically:
- Use the Azure database instead of in-memory storage
- Create database connections using Drizzle ORM
- Handle all CRUD operations through the database

## API Endpoints

Your backend now provides these REST API endpoints:

### Users
- `GET /api/users` - Get all users
- `GET /api/users/:id` - Get user by ID
- `POST /api/users` - Create new user
- `PATCH /api/users/:id` - Update user

### Events
- `GET /api/events` - Get all events (or filter by `?createdBy=userId`)
- `GET /api/events/:id` - Get event by ID
- `POST /api/events` - Create new event
- `PATCH /api/events/:id` - Update event

### Teams
- `GET /api/teams?eventId=id` - Get teams by event
- `GET /api/teams?userId=id` - Get teams by user
- `GET /api/teams/:id` - Get team by ID
- `POST /api/teams` - Create new team
- `PATCH /api/teams/:id` - Update team

### Submissions
- `GET /api/submissions?eventId=id` - Get submissions by event
- `GET /api/submissions?teamId=id` - Get submissions by team
- `GET /api/submissions/:id` - Get submission by ID
- `POST /api/submissions` - Create new submission
- `PATCH /api/submissions/:id` - Update submission

### Announcements
- `GET /api/announcements?eventId=id` - Get announcements by event
- `GET /api/announcements/:id` - Get announcement by ID
- `POST /api/announcements` - Create new announcement

### Health Check
- `GET /api/health` - Check API status

## Data Models

The database includes these main entities:

- **Users**: Name, username, password, skills, bio, avatar, role
- **Events**: Title, theme, tracks, rules, prizes, sponsors, mode, timeline
- **Teams**: Name, event association, member list
- **Submissions**: Title, description, GitHub/video links, track, tags, scores
- **Announcements**: Messages tied to specific events

All entities include timestamps and proper foreign key relationships.