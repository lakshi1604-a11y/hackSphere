import { storage } from "./storage";

// Seed the database with sample data for HackSphere
export async function seedDatabase() {
  try {
    console.log("🌱 Seeding database with sample data...");

    // Create sample users
    const users = [
      {
        name: "Lakshmi",
        username: "lakshmi",
        password: "hashed_password_1",
        skills: ["React", "UI/UX", "Arduino"],
        bio: "Frontend wizard + IoT tinkerer",
        avatar: "🪄",
        role: "participant"
      },
      {
        name: "Amrutha", 
        username: "amrutha",
        password: "hashed_password_2",
        skills: ["Python", "ML", "NLP"],
        bio: "ML generalist who ships fast",
        avatar: "🤖",
        role: "participant"
      },
      {
        name: "Himashi",
        username: "himashi", 
        password: "hashed_password_3",
        skills: ["Node", "SQL", "DevOps"],
        bio: "Loves scalable backends",
        avatar: "🛠️",
        role: "participant"
      },
      {
        name: "Saumya",
        username: "saumya",
        password: "hashed_password_4", 
        skills: ["Figma", "3D", "Three.js"],
        bio: "Design + 3D micro-interactions",
        avatar: "🎨",
        role: "participant"
      },
      {
        name: "Admin",
        username: "admin",
        password: "admin_password",
        skills: ["Management", "Strategy"],
        bio: "Platform administrator",
        avatar: "👑", 
        role: "organizer"
      }
    ];

    const createdUsers = [];
    for (const user of users) {
      const createdUser = await storage.createUser(user);
      createdUsers.push(createdUser);
      console.log(`✅ Created user: ${createdUser.name}`);
    }

    // Create a sample event
    const event = {
      title: "SynapHack 3.0 – HackSphere Demo",
      theme: "Event & Hackathon Hosting Platform",
      tracks: ["Core Platform", "AI Plagiarism", "Gamification"],
      rules: ["Team size up to 4", "Build MVP in 24h", "Original work only"],
      prizes: ["Best Innovation", "Best UI/UX", "Best Tech Stack"],
      sponsors: ["Synap Labs", "Azure", "MongoDB"],
      mode: "online",
      timeline: [
        { id: "t1", label: "Register", due: "2025-08-17", done: true },
        { id: "t2", label: "Build MVP", due: "2025-08-18", done: false },
        { id: "t3", label: "Submit", due: "2025-08-18", done: false },
        { id: "t4", label: "Demo Day", due: "2025-08-18", done: false }
      ],
      createdBy: createdUsers[4].id // Admin user
    };

    const createdEvent = await storage.createEvent(event);
    console.log(`✅ Created event: ${createdEvent.title}`);

    // Create a sample team
    const team = {
      eventId: createdEvent.id,
      name: "NeonBits",
      members: [createdUsers[0].id, createdUsers[2].id] // Lakshmi and Himashi
    };

    const createdTeam = await storage.createTeam(team);
    console.log(`✅ Created team: ${createdTeam.name}`);

    // Create a sample submission
    const submission = {
      eventId: createdEvent.id,
      teamId: createdTeam.id,
      title: "HackSphere – Social Feed + Map",
      description: "Gamified hackathon platform with AI judge copilot and swipe teaming.",
      github: "https://github.com/example/hacksphere",
      video: "https://youtu.be/dQw4w9WgXcQ",
      track: "Core Platform",
      tags: ["React", "Tailwind", "FramerMotion"],
      scores: []
    };

    const createdSubmission = await storage.createSubmission(submission);
    console.log(`✅ Created submission: ${createdSubmission.title}`);

    // Create a sample announcement
    const announcement = {
      eventId: createdEvent.id,
      message: "Welcome to HackSphere! 🚀 Drop your first submission when ready.",
      by: "System"
    };

    const createdAnnouncement = await storage.createAnnouncement(announcement);
    console.log(`✅ Created announcement: ${createdAnnouncement.message}`);

    console.log("🎉 Database seeded successfully!");
    
    return {
      users: createdUsers,
      event: createdEvent,
      team: createdTeam,
      submission: createdSubmission,
      announcement: createdAnnouncement
    };

  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}