import { 
  type User, type Event, type Team, type Submission, type Announcement,
  type InsertUser, type InsertEvent, type InsertTeam, type InsertSubmission, type InsertAnnouncement,
  users, events, teams, submissions, announcements
} from "@shared/schema";
import { randomUUID } from "crypto";
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Events
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined>;
  getAllEvents(): Promise<Event[]>;
  getEventsByCreator(createdBy: string): Promise<Event[]>;

  // Teams
  getTeam(id: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  updateTeam(id: string, team: Partial<InsertTeam>): Promise<Team | undefined>;
  getTeamsByEvent(eventId: string): Promise<Team[]>;
  getTeamsByUser(userId: string): Promise<Team[]>;

  // Submissions
  getSubmission(id: string): Promise<Submission | undefined>;
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  updateSubmission(id: string, submission: Partial<InsertSubmission>): Promise<Submission | undefined>;
  getSubmissionsByEvent(eventId: string): Promise<Submission[]>;
  getSubmissionsByTeam(teamId: string): Promise<Submission[]>;

  // Announcements
  getAnnouncement(id: string): Promise<Announcement | undefined>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  getAnnouncementsByEvent(eventId: string): Promise<Announcement[]>;
}

export class DatabaseStorage implements IStorage {
  private db: ReturnType<typeof drizzle>;
  private pool: Pool;

  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error("DATABASE_URL is required");
    }
    
    this.pool = new Pool({ 
      connectionString: process.env.DATABASE_URL,
      ssl: { rejectUnauthorized: false }
    });
    this.db = drizzle(this.pool);
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const userData = {
      ...user,
      skills: user.skills || [],
      role: user.role || "participant"
    } as any;
    const result = await this.db.insert(users).values(userData).returning();
    return result[0];
  }

  async updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined> {
    const result = await this.db.update(users).set(user as any).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getAllUsers(): Promise<User[]> {
    return await this.db.select().from(users);
  }

  // Events
  async getEvent(id: string): Promise<Event | undefined> {
    const result = await this.db.select().from(events).where(eq(events.id, id)).limit(1);
    return result[0];
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const eventData = {
      ...event,
      mode: event.mode || "online",
      tracks: event.tracks || [],
      rules: event.rules || [],
      prizes: event.prizes || [],
      sponsors: event.sponsors || [],
      timeline: event.timeline || []
    } as any;
    const result = await this.db.insert(events).values(eventData).returning();
    return result[0];
  }

  async updateEvent(id: string, event: Partial<InsertEvent>): Promise<Event | undefined> {
    const result = await this.db.update(events).set(event as any).where(eq(events.id, id)).returning();
    return result[0];
  }

  async getAllEvents(): Promise<Event[]> {
    return await this.db.select().from(events).orderBy(desc(events.createdAt));
  }

  async getEventsByCreator(createdBy: string): Promise<Event[]> {
    return await this.db.select().from(events).where(eq(events.createdBy, createdBy)).orderBy(desc(events.createdAt));
  }

  // Teams
  async getTeam(id: string): Promise<Team | undefined> {
    const result = await this.db.select().from(teams).where(eq(teams.id, id)).limit(1);
    return result[0];
  }

  async createTeam(team: InsertTeam): Promise<Team> {
    const teamData = {
      ...team,
      members: team.members || []
    } as any;
    const result = await this.db.insert(teams).values(teamData).returning();
    return result[0];
  }

  async updateTeam(id: string, team: Partial<InsertTeam>): Promise<Team | undefined> {
    const result = await this.db.update(teams).set(team as any).where(eq(teams.id, id)).returning();
    return result[0];
  }

  async getTeamsByEvent(eventId: string): Promise<Team[]> {
    return await this.db.select().from(teams).where(eq(teams.eventId, eventId)).orderBy(desc(teams.createdAt));
  }

  async getTeamsByUser(userId: string): Promise<Team[]> {
    // Note: This is a simplified approach. In a real implementation, you might want to use a proper JSON query
    const allTeams = await this.db.select().from(teams);
    return allTeams.filter(team => team.members?.includes(userId));
  }

  // Submissions
  async getSubmission(id: string): Promise<Submission | undefined> {
    const result = await this.db.select().from(submissions).where(eq(submissions.id, id)).limit(1);
    return result[0];
  }

  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const submissionData = {
      ...submission,
      tags: submission.tags || [],
      scores: submission.scores || []
    } as any;
    const result = await this.db.insert(submissions).values(submissionData).returning();
    return result[0];
  }

  async updateSubmission(id: string, submission: Partial<InsertSubmission>): Promise<Submission | undefined> {
    const result = await this.db.update(submissions).set(submission as any).where(eq(submissions.id, id)).returning();
    return result[0];
  }

  async getSubmissionsByEvent(eventId: string): Promise<Submission[]> {
    return await this.db.select().from(submissions).where(eq(submissions.eventId, eventId)).orderBy(desc(submissions.createdAt));
  }

  async getSubmissionsByTeam(teamId: string): Promise<Submission[]> {
    return await this.db.select().from(submissions).where(eq(submissions.teamId, teamId)).orderBy(desc(submissions.createdAt));
  }

  // Announcements
  async getAnnouncement(id: string): Promise<Announcement | undefined> {
    const result = await this.db.select().from(announcements).where(eq(announcements.id, id)).limit(1);
    return result[0];
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const result = await this.db.insert(announcements).values(announcement).returning();
    return result[0];
  }

  async getAnnouncementsByEvent(eventId: string): Promise<Announcement[]> {
    return await this.db.select().from(announcements).where(eq(announcements.eventId, eventId)).orderBy(desc(announcements.createdAt));
  }
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private events: Map<string, Event> = new Map();
  private teams: Map<string, Team> = new Map();
  private submissions: Map<string, Submission> = new Map();
  private announcements: Map<string, Announcement> = new Map();

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date(),
      skills: (insertUser.skills as string[]) || [],
      bio: insertUser.bio || null,
      avatar: insertUser.avatar || null,
      role: insertUser.role || "participant"
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userUpdate: Partial<InsertUser>): Promise<User | undefined> {
    const existing = this.users.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...userUpdate };
    this.users.set(id, updated);
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Events
  async getEvent(id: string): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const event: Event = { 
      ...insertEvent, 
      id, 
      createdAt: new Date(),
      mode: insertEvent.mode || "online",
      theme: insertEvent.theme || null,
      tracks: (insertEvent.tracks as string[]) || [],
      rules: (insertEvent.rules as string[]) || [],
      prizes: (insertEvent.prizes as string[]) || [],
      sponsors: (insertEvent.sponsors as string[]) || [],
      timeline: (insertEvent.timeline as any) || []
    };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: string, eventUpdate: Partial<InsertEvent>): Promise<Event | undefined> {
    const existing = this.events.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...eventUpdate };
    this.events.set(id, updated);
    return updated;
  }

  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async getEventsByCreator(createdBy: string): Promise<Event[]> {
    return Array.from(this.events.values()).filter(event => event.createdBy === createdBy);
  }

  // Teams
  async getTeam(id: string): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = randomUUID();
    const team: Team = { 
      ...insertTeam, 
      id, 
      createdAt: new Date(),
      members: (insertTeam.members as string[]) || []
    };
    this.teams.set(id, team);
    return team;
  }

  async updateTeam(id: string, teamUpdate: Partial<InsertTeam>): Promise<Team | undefined> {
    const existing = this.teams.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...teamUpdate };
    this.teams.set(id, updated);
    return updated;
  }

  async getTeamsByEvent(eventId: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(team => team.eventId === eventId);
  }

  async getTeamsByUser(userId: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(team => team.members?.includes(userId));
  }

  // Submissions
  async getSubmission(id: string): Promise<Submission | undefined> {
    return this.submissions.get(id);
  }

  async createSubmission(insertSubmission: InsertSubmission): Promise<Submission> {
    const id = randomUUID();
    const submission: Submission = { 
      ...insertSubmission, 
      id, 
      createdAt: new Date(),
      teamId: insertSubmission.teamId || null,
      github: insertSubmission.github || null,
      video: insertSubmission.video || null,
      track: insertSubmission.track || null,
      tags: (insertSubmission.tags as string[]) || [],
      scores: (insertSubmission.scores as any) || []
    };
    this.submissions.set(id, submission);
    return submission;
  }

  async updateSubmission(id: string, submissionUpdate: Partial<InsertSubmission>): Promise<Submission | undefined> {
    const existing = this.submissions.get(id);
    if (!existing) return undefined;
    const updated = { ...existing, ...submissionUpdate };
    this.submissions.set(id, updated);
    return updated;
  }

  async getSubmissionsByEvent(eventId: string): Promise<Submission[]> {
    return Array.from(this.submissions.values()).filter(sub => sub.eventId === eventId);
  }

  async getSubmissionsByTeam(teamId: string): Promise<Submission[]> {
    return Array.from(this.submissions.values()).filter(sub => sub.teamId === teamId);
  }

  // Announcements
  async getAnnouncement(id: string): Promise<Announcement | undefined> {
    return this.announcements.get(id);
  }

  async createAnnouncement(insertAnnouncement: InsertAnnouncement): Promise<Announcement> {
    const id = randomUUID();
    const announcement: Announcement = { ...insertAnnouncement, id, createdAt: new Date() };
    this.announcements.set(id, announcement);
    return announcement;
  }

  async getAnnouncementsByEvent(eventId: string): Promise<Announcement[]> {
    return Array.from(this.announcements.values()).filter(ann => ann.eventId === eventId);
  }
}

export const storage: IStorage = process.env.DATABASE_URL
? new DatabaseStorage()
: new MemStorage();

