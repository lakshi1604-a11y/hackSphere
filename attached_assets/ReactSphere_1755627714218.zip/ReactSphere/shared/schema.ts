import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, json, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  skills: json("skills").$type<string[]>().notNull().default([]),
  bio: text("bio"),
  avatar: text("avatar"),
  role: text("role").notNull().default("participant"), // participant, organizer, judge
  createdAt: timestamp("created_at").defaultNow(),
});

// Events table
export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  theme: text("theme"),
  tracks: json("tracks").$type<string[]>().notNull().default([]),
  rules: json("rules").$type<string[]>().notNull().default([]),
  prizes: json("prizes").$type<string[]>().notNull().default([]),
  sponsors: json("sponsors").$type<string[]>().notNull().default([]),
  mode: text("mode").notNull().default("online"), // online, offline, hybrid
  timeline: json("timeline").$type<Array<{id: string, label: string, due: string, done: boolean}>>().notNull().default([]),
  createdBy: varchar("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Teams table
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull(),
  name: text("name").notNull(),
  members: json("members").$type<string[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

// Submissions table
export const submissions = pgTable("submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull(),
  teamId: varchar("team_id"),
  title: text("title").notNull(),
  description: text("description").notNull(),
  github: text("github"),
  video: text("video"),
  track: text("track"),
  tags: json("tags").$type<string[]>().notNull().default([]),
  scores: json("scores").$type<Array<{judgeId: string, round: number, score: number, feedback: string}>>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

// Announcements table
export const announcements = pgTable("announcements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  eventId: varchar("event_id").notNull(),
  message: text("message").notNull(),
  by: text("by").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Create insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertEventSchema = createInsertSchema(events).omit({ id: true, createdAt: true });
export const insertTeamSchema = createInsertSchema(teams).omit({ id: true, createdAt: true });
export const insertSubmissionSchema = createInsertSchema(submissions).omit({ id: true, createdAt: true });
export const insertAnnouncementSchema = createInsertSchema(announcements).omit({ id: true, createdAt: true });

// Create types
export type User = typeof users.$inferSelect;
export type Event = typeof events.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type Submission = typeof submissions.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;
